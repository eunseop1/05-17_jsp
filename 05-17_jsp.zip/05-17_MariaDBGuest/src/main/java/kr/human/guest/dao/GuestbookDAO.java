package kr.human.guest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.human.JDBCUtill;
import kr.human.guest.vo.GuestbookVO;

/*
DB에 관계된 CRUD 명령어 처리
SQL명령어 1개당 메서드 1개
 트랜젝션 처리때문에 Connection을 인수로 받자
 싱글톤 패턴으로 작성하자
*/
public class GuestbookDAO {
	//싱글톤으로 만들자
	private static GuestbookDAO instance = new GuestbookDAO();
	private GuestbookDAO() {}
	
	public static GuestbookDAO getInstance() {
		return instance;
	}
	//------------------------------------------------------------------
	
	//1. 전체 개수 구하기
	public int selectCount(Connection conn) throws SQLException {
		int count = 0;//리턴타입의 변수를 만든다
		String sql = "select count(*) from guestbook";//실행할 SQl 명령어를 만든다
		Statement stmt = conn.createStatement();//명령 객체를 만든다
		ResultSet rs = stmt.executeQuery(sql);//명령실행 (rs는 select할때만 사용한다)
		rs.next();
		count = rs.getInt(1);//결과 얻기 
//(SQL명령어가 한줄이고 count(*)하나만 존재하기에 1이라고만 한다. 만약 "select count(*) as cnt"이라면 rs.getInt("cnt")로도 작동한다 )
		JDBCUtill.close(rs);//닫기
		JDBCUtill.close(stmt);
		return count;//결과 보내기
	}
	
	//2. 1개 얻기
	public GuestbookVO selectByIdx(Connection conn, int idx) throws SQLException {
		GuestbookVO vo = null;
		String sql = "select * from guestbook where idx=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, idx);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			vo = new GuestbookVO();
			vo.setIdx(rs.getInt("idx"));
			vo.setName(rs.getString("name"));
			vo.setPassword(rs.getString("password"));
			vo.setContent(rs.getString("content"));
			vo.setRegDate(rs.getTimestamp("regDate"));
			vo.setIp(rs.getString("ip"));
		}
		JDBCUtill.close(rs);
		JDBCUtill.close(pstmt);
		return vo;
	}
	//3. 1페이지 분량의 데이터 얻기
	public List<GuestbookVO> selectList(Connection conn, int startNo, int pageSize) throws SQLException{
		List<GuestbookVO> list = null;
		String sql = "select * from guestbook order by idx desc limit ?, ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, startNo);
		pstmt.setInt(2, pageSize);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			list = new ArrayList<>();
			do {
				GuestbookVO vo = new GuestbookVO();
				vo.setIdx(rs.getInt("idx"));
				vo.setName(rs.getString("name"));
				vo.setPassword(rs.getString("password"));
				vo.setContent(rs.getString("content"));
				vo.setRegDate(rs.getTimestamp("regDate"));
				vo.setIp(rs.getString("ip"));
				
				list.add(vo);
			}while(rs.next());
		}
		JDBCUtill.close(rs);
		JDBCUtill.close(pstmt);
		return list;
	}
	//4. 저장하기
	public int insert(Connection conn, GuestbookVO vo) throws SQLException {
		int count = 0;
		String sql = "insert into guestbook (name,password,content,ip) values(?, ?, ?, ?)";//실행할 SQl 명령어를 만든다
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, vo.getName());
		pstmt.setString(2, vo.getPassword());
		pstmt.setString(3, vo.getContent());
		pstmt.setString(4, vo.getIp());
		
		count = pstmt.executeUpdate();
		JDBCUtill.close(pstmt);//닫기
		return count;//결과 보내기
	}
	
	//5. 수정하기
	public int update(Connection conn, GuestbookVO vo) throws SQLException {
		int count = 0;
		String sql = "update guestbook set content=?, refdate=now(), ip=? where idx=?";//실행할 SQl 명령어를 만든다
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, vo.getContent());
		pstmt.setString(2, vo.getIp());
		pstmt.setInt(3, vo.getIdx());
		
		count = pstmt.executeUpdate();
		JDBCUtill.close(pstmt);//닫기
		return count;//결과 보내기
	}
	
	//6. 삭제하기
	public int delete(Connection conn, int idx) throws SQLException {
		int count = 0;
		String sql = "delete from guestbook where idx=?";//실행할 SQl 명령어를 만든다
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, idx);
		
		count = pstmt.executeUpdate();
		JDBCUtill.close(pstmt);//닫기
		return count;//결과 보내기
	}
}
